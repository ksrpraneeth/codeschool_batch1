(function ($, window, document) {
    $(() => {
        console.log("DOM is ready");

        // Hide sidebar
        $("#sidebarToggler").click(() => {
            $("#sidebar").toggleClass("hide")
        });
    });
})(window.jQuery, window, document);
